import React, { Component } from 'react';
import ArticleSection from './components/article-section';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

class App extends Component {
  componentDidMount() {
    // call default function to display redux operation
    //this.props.defaultFunction();
  }
  render() {
      return (
        <ArticleSection/>
    )
  }
}

export default App;
