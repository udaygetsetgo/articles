import React from 'react'
import { Tabs, Tab } from 'react-bootstrap';
import axios from 'axios';

class CreateArticle extends React.Component{
  constructor(props){
    super(props);
    this.state = {
      title: '',
      desc: '',
      votes: 0
    }
    this.handleClick = this.handleClick.bind(this);
    this.onChangeTitle = this.onChangeTitle.bind(this);
    this.onChangeDesc = this.onChangeDesc.bind(this);
  }

  handleClick(e) {
      e.preventDefault();
      const article = {
        title:this.state.title,
        desc: this.state.desc,
        votes: this.state.votes
      }
      axios.post(`http://localhost:3041/articles`, {article})
      .then(res => {
        console.log('res', res);
        console.log('data', res.data);
      })
      //handle Save article code
  }

  onChangeTitle(e) {
      this.setState(Object.assign({}, this.state, {
        title : e.target.value
      }))
  }

 onChangeDesc(e) {
    this.setState(Object.assign({}, this.state, {
        desc : e.target.value
    }))
  }
    
  render() {
    return (
      <div>
          <h3> Add New Article</h3>
          <div className="form-group">
            <label htmlFor="title">Title:</label>
            <input type="text" placeholder="Enter the title" required="required" className="form-control" id="title" defaultValue={this.state.title} onChange = {(e) => this.onChangeTitle(e)} />
          </div>
          <div className="form-group">
            <label htmlFor="description">Description:</label>
            <textarea type="text" placeholder="Enter the Description" className="form-control" id="desc" defaultValue={this.state.desc} onChange = {(e) => this.onChangeDesc(e)} />
          </div>
          <div className="form-group">
            <button
              className="btn btn-primary"
              onClick={(e) => this.handleClick(e)}
              disabled = {this.state.title === '' || this.state.desc === ''}>Add Article
            </button>
          </div>
      </div>
    )
  }
}

export default CreateArticle;