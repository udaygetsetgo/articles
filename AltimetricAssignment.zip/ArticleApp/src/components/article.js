import React from 'react'
import axios from 'axios'
import 'font-awesome/css/font-awesome.min.css'; 

class Article extends React.Component{
  constructor(props){
    super(props);
    this.state = props.data
    this.handleUpVote = this.handleUpVote.bind(this);
    this.handleDownVote = this.handleDownVote.bind(this);
  }

  handleUpVote(e) {
    let updatedArticle = {
      title: this.state.article.title,
      desc: this.state.article.desc,
      votes: this.state.article.votes + 1
    }
    this.setState(Object.assign({}, this.state, {article: updatedArticle}))
    axios.put(`http://localhost:3041/articles/${this.state.id}`, this.state).then(res => {
      console.log('res', res);
      console.log('data', res.data);
    })
  }

  handleDownVote(e) {
    let updatedArticle = {
      title: this.state.article.title,
      desc: this.state.article.desc,
      votes: this.state.article.votes > 0 ? this.state.article.votes - 1 : 0
    }
    this.setState(Object.assign({}, this.state, {article: updatedArticle}))
    axios.put(`http://localhost:3041/articles/${this.state.id}`, this.state).then(res => {
      console.log('res', res);
      console.log('data', res.data);
    })
  }
    
  render() {
    return (
      <div>
        <h3>{this.props.data.article.title}</h3>
        <hr/>
        <p>{this.props.data.article.desc}</p>
        Vote
        <div><i onClick={(e) => this.handleUpVote(e)} className="fa fa-thumbs-up green" aria-hidden="true"></i></div>
        {this.state.article.votes}
        <div><i onClick={(e) => this.handleDownVote(e)} className="fa fa-thumbs-down red" aria-hidden="true"></i></div>
      </div>
    )
  }
}

export default Article;