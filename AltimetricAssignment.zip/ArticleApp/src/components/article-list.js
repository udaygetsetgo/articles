import React from 'react'
import { Tabs, Tab } from 'react-bootstrap';
import {saveFormDetails} from '../actions';
import axios from 'axios';
import Article from './article';

class ArticleList extends React.Component{
  render() {
      return (
          <div>
            <h2>Article List</h2>
            <ul className="list">{this.props.articles.map(article => <li className="list-item" key={article.id}><Article data={article}/></li>)}</ul>
          </div>
      )
  }
}

export default ArticleList;