import React from 'react';
import { Tabs, Tab } from 'react-bootstrap';
import CreateArticle from './create-article';
import ArticleList from './article-list';
import axios from 'axios';

class ArticleSection extends React.Component{
  constructor(props) {
    super(props)
    this.state = {
      activeTab:1,
      articles:[]
    }
    this.setActiveTab = this.setActiveTab.bind(this);
  }

  setActiveTab(e) {
    this.setState({activeTab:e.target.id})
  }

  componentDidMount(){
    console.log('didmount')
    axios.get(`http://localhost:3041/articles`)
      .then(res => {
        this.setState({ articles: res.data})
      })
  }

  render() {
      return (
        <div className="container">
          Note: Please refresh the page after adding the article to reflect the updated list 
          <Tabs defaultActiveKey={1} animation={false} id="noanim-tab-example" className='navs nav-tabs'>
            <Tab eventKey={1} title="Create Article" className="tab"
              onActiveTab={ (e) => this.setActiveTab(e.target.id) }>
              <CreateArticle/>
            </Tab>
            <Tab eventKey={2} title="Article List" className="tab" onActiveTab={ (e) => this.setActiveTab(e.target.id) }>
              <ArticleList articles={this.state.articles}/>
            </Tab>
          </Tabs>
        </div>
      )
  }
}

export default ArticleSection;