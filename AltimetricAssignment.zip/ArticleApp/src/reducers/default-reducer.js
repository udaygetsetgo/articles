// default reducer
// Note: You can remove this reducer and create your own reducer

import { FETCH_DATA, SAVE_DATA } from '../actions';

export default (state = {}, action) => {
    switch(action.type) {
        case FETCH_DATA:
            return action.payload;
        case SAVE_DATA:
            return Object.assign({}, state, {textValue: action.payload})
        default:
            return state;
    }
}